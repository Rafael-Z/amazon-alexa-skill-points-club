'use strict'

const config = {
    'HIGH_BALANCE_THRESHOLD':100000,
    'NUM_LAST_TRANSACTIONS': 5,
    'NUM_EXPIRING_ACCRUALS': 5
}

module.exports = config